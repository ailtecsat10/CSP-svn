#!/bin/ash
ifconfig