#!/bin/ash

rm -rf /tmp/dropbear
rm -rf /tmp/.ssh
